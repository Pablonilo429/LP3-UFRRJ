package Exercicio3;
public class Livro{
    String Titulo;
    String Autor;

    public Livro(){
    }
    public void setTitulo(String Titulo){
        this.Titulo = Titulo;
    }
    public String getTitulo() {
        return Titulo;
    }
    public void setAutor(String Autor){
        this.Autor = Autor;
    }
    public String getAutor() {
        return Autor;
    }


}